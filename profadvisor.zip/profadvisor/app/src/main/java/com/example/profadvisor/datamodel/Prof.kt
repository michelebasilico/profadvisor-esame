package com.example.profadvisor.datamodel

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

/**
 * Classe per rappresentare una birra nella raccolta
 */
@Parcelize
data class Prof(var nome: String, var materia: String, var email: String) : Parcelable