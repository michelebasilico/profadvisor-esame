package com.example.profadvisor

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.navigation.Navigation
import androidx.recyclerview.widget.RecyclerView
import com.example.profadvisor.datamodel.Prof

/**
 * Adapter utilizzato per la RecyclerView con l'elenco delle birre
 *
 */
class ProfAdapter(val dataset: ArrayList<Prof>, val context: Context) : RecyclerView.Adapter<RigaProfViewHolder>() {

    // Invocata per creare un ViewHolder
    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): RigaProfViewHolder {
        // Crea e restituisce un viewholder, effettuando l'inflate del layout relativo alla riga
        return RigaProfViewHolder(LayoutInflater.from(context).inflate(R.layout.prof_riga, viewGroup, false))
    }

    // Invocata per conoscere quanti elementi contiene il dataset
    override fun getItemCount(): Int {
        return dataset.size
    }

    // Invocata per visualizzare all'interno del ViewHolder il dato corrispondente alla riga
    override fun onBindViewHolder(viewHolder: RigaProfViewHolder, position: Int) {
        val prof = dataset.get(position)

        viewHolder.tvNome.text = prof.nome
        viewHolder.tvMateria.text = prof.materia
        viewHolder.tvEmail.text = prof.email

        // Imposto il listner per passare a visualizzare il dettaglio
        viewHolder.itemView.setOnClickListener {

            // Creo un bundle e vi inserisco il prof da visualizzare
            val b = Bundle()
            b.putParcelable("prof", prof)     //TODO: Il nome dell'ogggetto andrebbe inserito in un solo punto!!
            Navigation.findNavController(it).navigate(R.id.action_profFragment_to_unProfFragment, b)
        }
    }
}