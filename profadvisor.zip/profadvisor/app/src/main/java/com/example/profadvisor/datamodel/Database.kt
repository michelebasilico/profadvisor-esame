package com.example.profadvisor.datamodel

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase

object Database {

    var auth= FirebaseAuth.getInstance()
    private var database = FirebaseDatabase.getInstance()
    val uid = FirebaseAuth.getInstance().uid!!

    // Array per simulare il contenuto del database
    private var professori = ArrayList<Prof>()
    private val NODO_PROF = "professori"

    // Inizializzatore per popolare il database con qualche dato
    init {
        professori.add(Prof("Pasquale Cantiello", "Android","pasquale.cantiello@unicampania.it"))
        professori.add(Prof("Rocco Aversa", "Sistemi Operativi", "rocco.aversa@unicampania.it"))
        professori.add(Prof("Salvatore Venticinque", "Elementi di programmazzione","salvatore.venticinque@unicampania.it"))
    }

    // Restituisce l'elenco di tutte le birre presenti
    fun getElencoProf(): ArrayList<Prof> {
        return professori
    }

    /**
     * Aggiunge una nuova birra nel database
     */
    fun salvaProf(prof: Prof) {
        professori.add(prof)
    }
}